'neoapi - camera experience'
name = 'neoapi'
import os
if os.name == 'nt':
    cur_dir = os.path.dirname(__file__)
    path = os.environ.get('PATH', '')
    if not path:
        os.environ['PATH'] = cur_dir
    elif not cur_dir in path.split(os.pathsep):
        os.environ['PATH'] += os.pathsep + cur_dir
from .neoapi import *
