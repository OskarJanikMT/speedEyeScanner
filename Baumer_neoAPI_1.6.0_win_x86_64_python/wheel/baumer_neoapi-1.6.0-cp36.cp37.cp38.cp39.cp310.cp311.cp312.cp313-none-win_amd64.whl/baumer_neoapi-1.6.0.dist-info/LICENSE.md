
# LICENSE AGREEMENT (�EULA� End User License Agreement)

IMPORTANT, PLEASE READ CAREFULLY: This is a legally binding agreement between the person, company, or organization which has obtained the software (hereinafter: �You�) and Baumer Optronic GmbH (hereinafter: �Baumer�) governing the use of the software �Baumer GAPI SDK� (hereinafter: the �Software�).

Your use of the Software constitutes your agreement with the terms and conditions of this agreement (EULA).

The Software comprises the Software which can be executed on a computer, any enclosed media, and the user documentation in both its printed and electronic forms.
Baumer retains sole proprietary title to the Software, which is protected by the copyright laws of Germany and international treaty provisions.
Any and all rights to the Software and its intellectual property belong to and are retained by Baumer. You are licensing, not purchasing the Software.

## SCOPE AND RESTRICTIONS OF LICENSE.
1. Permission is hereby granted, free of charge, to any person obtaining a copy of this Software to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

2. Term and termination: this agreement (�EULA�) concerning the utilization of the Software provided to You is valid for an indefinite term, provided that there is no infringement on other rights. Baumer reserves the right to terminate this EULA if and when you are in breach of the provisions contained therein. In this case, any and all copies of the Software and its individual components must be destroyed.


## OTHER RIGHTS AND RESTRICTIONS

1. Intellectual property: any and all rights, including, but not limited to, copyrights, business secrets, patents, and trademarks related to the Software and to any and all images which may be integrated in the Software, accompanying printed material, and any and all copies of the Software, are retained by Baumer as the sole and exclusive owner of the intellectual property.
2. NO GUARANTEE AND WARRANTY: DESPITE ALL OF THE EFFORTS WHICH HAVE BEEN MADE TO ASSURE THE CORRECTNESS AND THE USABILITY OF THE SOFTWARE AND ITS CONFORMITY WITH THE DOCUMENTATION, BAUMER DOES NOT ASSUME ANY GUARANTEES OR WARRANTIES, EITHER EXPRESS OR IMPLICIT, INCLUDING, BUT NOT LIMITED TO, MARKET CAPABILITY OR SUITABILITY FOR SPECIFIC PURPOSES, RELATED TO THE SOFTWARE AND THE RELEVANT WRITTEN MATERIAL TO THE FULL EXTENT PERMISSIBLE IN ACCORDANCE WITH APPLICABLE LAW.
3. NO LIABILITY FOR SUBSEQUENT DAMAGE OR LOSS: UNDER NO CIRCUMSTANCES CAN BAUMER BE MADE LIABLE FOR ANY LOSS OR DAMAGE, REGARDLESS OF ITS NATURE, SUFFERED BECAUSE OF THE USE OF, OR THE INABILITY TO USE, THE SOFTWARE, EVEN IF AND WHEN BAUMER HAS BEEN NOTIFIED OF THE POSSIBLE OCCURRENCE OF SUCH LOSS OR DAMAGE. THE ABOVE PROVISION INCLUDES WITHOUT EXCEPTION LOSS OR DAMAGE FROM LOST PROFIT, OPERATIONAL INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER FINANCIAL LOSS.
4. NO LIABILITY WITH RESPECT TO THIRD PARTIES: YOU HEREBY INDEMNIFY AND HOLD HARMLESS BAUMER FROM AND AGAINST ANY AND ALL THIRD-PARTY CLAIMS WHICH THIRD PARTIES MAY ASSERT AGAINST YOU PURSUANT TO THE USE OF THE SOFTWARE. MOREOVER, YOU SHALL BEAR ANY AND ALL EXPENDITURES REQUIRED FOR THE DEFENSE AGAINST SUCH CLAIMS.
5. Baumer grants the right to reverse-engineer, debug, and decompile proprietary components of the Software for the only purpose of and only to the extent necessary to achieve the interoperability of the Software with another independently created computer program. The distribution of any results (e. g. modified version of components of the Software) is prohibited. The information gained by reverse-engineering shall be held by you in strict confidence and shall not be used for the development, production or marketing of a computer program substantially similar in its expression, or for any other act which infringes copyright. BAUMER�S LIABILITY FOR ANY DAMAGES OR LOSSS OCCURRING IN CONJUNCTION WITH REVERSE-ENGINEERING OR MODIFICATION OF THE SOFTWARE OR OTHERWISE IS EXCLUDED.
6. Modifications: this agreement or EULA may not be modified in favor of one party, whether by addendum or by deletion or amendment of the text in any way, unless both parties agree to such modifications in writing.
7. Partial validity: should any part of this EULA be declared invalid, illegal, unenforceable, or void by a recognized court, the remaining parts of this EULA shall remain valid in full. However, such partial validity shall not have any effect if and when it is detrimental to the commercial benefits of the EULA for Baumer.
8 Power of representation for execution and acceptance: by accepting this EULA, You expressly confirm that You have read and understood this EULA in full and that you accept the obligations pursuant thereto with respect to Baumer. Furthermore, you hereby declare that the person accepting this EULA is in possession of the appropriate power of representation.


## Open Source Software

Parts of the Baumer GAPI Software utilizes Open-Source Software. 
These Open-Source Software are owned by their respective owners, Baumer does not claim any copyright for these Software.
Where required Baumer provides the source-code as well as any Baumer specific changes to the source-code for the Open-Source Software. You can request the source-code from the Baumer Support (support.cameras@baumer.com) for a minimum of 3 years after the Baumer GAPI SDK was released.
Following you can find the list of utilized Open-Source Software as well as Copyright Notices and Licenses in no particular order.


### GenICam Runtime Version
http://www.emva.org/
Copyright (c) 2005-2018, EMVA and contributors (see source files). All rights reserved.
Redistribution and use in source and binary forms, without modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. 
2. Redistributions  in  binary  form  must  reproduce  the  above  copyright  notice,  this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. 
3. Neither  the  name  of  the  GenICam  standard  group  nor  the  names  of  its contributors  may  be  used  to  endorse  or  promote  products  derived  from  this software without specific prior written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### Math Parser
http://kirya.narod.ru/mathparser.html
Copyright (C) Kirill Zaborski, zkv@mail.ru. 
This Software is distributed under the LGPL v.3. A copy of this license is available below.

### Log4cpp
http://log4cpp.sourceforge.net
Copyright (C) 2000-2002 LifeLine Networks bv, Copyright (C) 2000-2002 Bastiaan Bakker Portions Copyright others, see file THANKS and source code. 
This Software is distributed under the LGPL v.3. A copy of this license is available below.

### QT

The following parts of the software use Qt:
- Baumer Camera Explorer
- Baumer Driver Manager
- Baumer Update Tool
- Baumer IP Config Tool

https://www.qt.io/
Copyright (C) 2015 The QT Company Ltd.
This Software is distributed under the LGPL v.3. A copy of this license is available below.

### QTPropertyBrowser
https://github.com/intbots/QtPropertyBrowser
Copyright (C) 2010 Nokia Corporation and/or its subsidiary(-ies). All rights reserved.
This Software is distributed under the 3-clause BSD Licence. A copy of this license is available below.

### Json Spirit
https://github.com/sirikata/json-spirit
Copyright (c) 2007 - 2010 John W. Wilkinson. 
This Software is distributed under the MIT License. A copy of this license is available below.

### Md5 Message Digest
https://www.rsa.com
Copyright (C) 1991-2, RSA Data Security, Inc. Created 1991. All rights reserved.
License to copy and use this software is granted provided that it is identified as the "RSA Data Security, Inc. MD5 Message-Digest Algorithm" in all material mentioning or referencing this software or this function.
License is also granted to make and use derivative works provided that such works are identified as "derived from the RSA Data Security, Inc. MD5 Message-Digest Algorithm" in all material mentioning or referencing the derived work.
RSA Data Security, Inc. makes no representations concerning either the merchantability of this software or the suitability of this software for any particular purpose. It is provided "as is" without express or implied warranty of any kind.
These notices must be retained in any copies of any part of this documentation and/or software.

### OpenJpeg
https://github.com/uclouvain/openjpeg
The copyright in this software is being made available under the 2-clauses BSD License. A copy of this license is available below. This software may be subject to other third party and contributor rights, including patent rights, and no such rights are granted under this license.

Copyright (c) 2002-2014, Universite catholique de Louvain (UCL), Belgium
Copyright (c) 2002-2014, Professor Benoit Macq
Copyright (c) 2003-2014, Antonin Descampe
Copyright (c) 2003-2009, Francois-Olivier Devaux
Copyright (c) 2005, Herve Drolon, FreeImage Team
Copyright (c) 2002-2003, Yannick Verschueren
Copyright (c) 2001-2003, David Janssens
Copyright (c) 2011-2012, Centre National d'Etudes Spatiales (CNES), France 
Copyright (c) 2012, CS Systemes d'Information, France
All rights reserved.

### OpenCV
https://github.com/opencv/
Copyright (C) 2000-2016, Intel Corporation, all rights reserved.
Copyright (C) 2009-2011, Willow Garage Inc., all rights reserved.
Copyright (C) 2009-2016, NVIDIA Corporation, all rights reserved.
Copyright (C) 2010-2013, Advanced Micro Devices, Inc., all rights reserved.
Copyright (C) 2015-2016, OpenCV Foundation, all rights reserved.
Copyright (C) 2015-2016, Itseez Inc., all rights reserved.
Third party copyrights are property of their respective owners.
This Software is distributed under the 3-clause BSD License. A copy of this license is available below.

### FFmpeg
https://www.ffmpeg.org
This Software is distributed under the LGPL v.3. A copy of this license is available below.

### Cmake
https://cmake.org
Copyright 2000-2017 Kitware, Inc. and Contributors, All rights reserved. 
This Software is distributed under the 3-clause BSD License. A copy of this license is available below. 





## Open Source Licenses

### LGPL v.3
https://opensource.org/licenses/LGPL-3.0

                   GNU LESSER GENERAL PUBLIC LICENSE
                       Version 3, 29 June 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.


  This version of the GNU Lesser General Public License incorporates
the terms and conditions of version 3 of the GNU General Public
License, supplemented by the additional permissions listed below.

  0. Additional Definitions.

  As used herein, "this License" refers to version 3 of the GNU Lesser
General Public License, and the "GNU GPL" refers to version 3 of the GNU
General Public License.

  "The Library" refers to a covered work governed by this License,
other than an Application or a Combined Work as defined below.

  An "Application" is any work that makes use of an interface provided
by the Library, but which is not otherwise based on the Library.
Defining a subclass of a class defined by the Library is deemed a mode
of using an interface provided by the Library.

  A "Combined Work" is a work produced by combining or linking an
Application with the Library.  The particular version of the Library
with which the Combined Work was made is also called the "Linked
Version".

  The "Minimal Corresponding Source" for a Combined Work means the
Corresponding Source for the Combined Work, excluding any source code
for portions of the Combined Work that, considered in isolation, are
based on the Application, and not on the Linked Version.

  The "Corresponding Application Code" for a Combined Work means the
object code and/or source code for the Application, including any data
and utility programs needed for reproducing the Combined Work from the
Application, but excluding the System Libraries of the Combined Work.

  1. Exception to Section 3 of the GNU GPL.

  You may convey a covered work under sections 3 and 4 of this License
without being bound by section 3 of the GNU GPL.

  2. Conveying Modified Versions.

  If you modify a copy of the Library, and, in your modifications, a
facility refers to a function or data to be supplied by an Application
that uses the facility (other than as an argument passed when the
facility is invoked), then you may convey a copy of the modified
version:

   a) under this License, provided that you make a good faith effort to
   ensure that, in the event an Application does not supply the
   function or data, the facility still operates, and performs
   whatever part of its purpose remains meaningful, or

   b) under the GNU GPL, with none of the additional permissions of
   this License applicable to that copy.

  3. Object Code Incorporating Material from Library Header Files.

  The object code form of an Application may incorporate material from
a header file that is part of the Library.  You may convey such object
code under terms of your choice, provided that, if the incorporated
material is not limited to numerical parameters, data structure
layouts and accessors, or small macros, inline functions and templates
(ten or fewer lines in length), you do both of the following:

   a) Give prominent notice with each copy of the object code that the
   Library is used in it and that the Library and its use are
   covered by this License.

   b) Accompany the object code with a copy of the GNU GPL and this license
   document.

  4. Combined Works.

  You may convey a Combined Work under terms of your choice that,
taken together, effectively do not restrict modification of the
portions of the Library contained in the Combined Work and reverse
engineering for debugging such modifications, if you also do each of
the following:

   a) Give prominent notice with each copy of the Combined Work that
   the Library is used in it and that the Library and its use are
   covered by this License.

   b) Accompany the Combined Work with a copy of the GNU GPL and this license
   document.

   c) For a Combined Work that displays copyright notices during
   execution, include the copyright notice for the Library among
   these notices, as well as a reference directing the user to the
   copies of the GNU GPL and this license document.

   d) Do one of the following:

       0) Convey the Minimal Corresponding Source under the terms of this
       License, and the Corresponding Application Code in a form
       suitable for, and under terms that permit, the user to
       recombine or relink the Application with a modified version of
       the Linked Version to produce a modified Combined Work, in the
       manner specified by section 6 of the GNU GPL for conveying
       Corresponding Source.

       1) Use a suitable shared library mechanism for linking with the
       Library.  A suitable mechanism is one that (a) uses at run time
       a copy of the Library already present on the user's computer
       system, and (b) will operate properly with a modified version
       of the Library that is interface-compatible with the Linked
       Version.

   e) Provide Installation Information, but only if you would otherwise
   be required to provide such information under section 6 of the
   GNU GPL, and only to the extent that such information is
   necessary to install and execute a modified version of the
   Combined Work produced by recombining or relinking the
   Application with a modified version of the Linked Version. (If
   you use option 4d0, the Installation Information must accompany
   the Minimal Corresponding Source and Corresponding Application
   Code. If you use option 4d1, you must provide the Installation
   Information in the manner specified by section 6 of the GNU GPL
   for conveying Corresponding Source.)

  5. Combined Libraries.

  You may place library facilities that are a work based on the
Library side by side in a single library together with other library
facilities that are not Applications and are not covered by this
License, and convey such a combined library under terms of your
choice, if you do both of the following:

   a) Accompany the combined library with a copy of the same work based
   on the Library, uncombined with any other library facilities,
   conveyed under the terms of this License.

   b) Give prominent notice with the combined library that part of it
   is a work based on the Library, and explaining where to find the
   accompanying uncombined form of the same work.

  6. Revised Versions of the GNU Lesser General Public License.

  The Free Software Foundation may publish revised and/or new versions
of the GNU Lesser General Public License from time to time. Such new
versions will be similar in spirit to the present version, but may
differ in detail to address new problems or concerns.

  Each version is given a distinguishing version number. If the
Library as you received it specifies that a certain numbered version
of the GNU Lesser General Public License "or any later version"
applies to it, you have the option of following the terms and
conditions either of that published version or of any later version
published by the Free Software Foundation. If the Library as you
received it does not specify a version number of the GNU Lesser
General Public License, you may choose any version of the GNU Lesser
General Public License ever published by the Free Software Foundation.

  If the Library as you received it specifies that a proxy can decide
whether future versions of the GNU Lesser General Public License shall
apply, that proxy's public statement of acceptance of any version is
permanent authorization for you to choose that version for the Library.


### BSD 2-Clause
https://opensource.org/licenses/BSD-2-Clause
Copyright (c) <year>, <copyright holder>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the FreeBSD Project.


### BSD 3-Clause
https://opensource.org/licenses/BSD-3-Clause

Copyright (c) <year>, <copyright holder>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


### MIT Licence
https://opensource.org/licenses/MIT
Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

